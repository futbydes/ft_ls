/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strsub.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/30 13:15:22 by vludan            #+#    #+#             */
/*   Updated: 2017/11/01 19:33:58 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

char	*ft_strsub(char const *s, unsigned int start, size_t len)
{
	char	*a;
	unsigned int	x;
	unsigned int	z;

	x = 0;
	z = 0;
	a = malloc(sizeof(char) * (len));
	while ((s[start] != '\0') && (len != 0))
	{
		a[z++] = s[start++];
		len--;
	}
	return (a);
}

int		main(void)
{
	char const	s[20] = "AamsaBamsaCamsa";
	unsigned int	start = 6;
	size_t	len = 26;

	printf("%s",ft_strsub(s,start,len));
	return (0);
}
