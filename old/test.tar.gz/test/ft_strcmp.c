/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/28 20:41:16 by vludan            #+#    #+#             */
/*   Updated: 2017/10/29 14:37:34 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>

int		ft_strcmp(const char *s1, const char *s2)
{
	unsigned char	*c;
	unsigned char	*b;
	int				x;

	x = 0;
	c = (unsigned char*)s1;
	b = (unsigned char*)s2;
	while (c[x] == b[x])
		x++;
	return (c[x] - b[x]);
}
