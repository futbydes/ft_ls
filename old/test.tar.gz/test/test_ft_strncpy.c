/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/27 17:57:45 by vludan            #+#    #+#             */
/*   Updated: 2017/11/04 16:21:49 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

char	*ft_strncpy(char *dst, const char *src, size_t len)
{
	size_t	count;

	count = 0;
	while ((count != len) && (src[count] != '\0'))
	{
		dst[count] = src[count];
		count++;
	}
	while (count != len)
		dst[count++] = '\0';
	return (dst);
}

int		main(void)
{
	size_t	len = 5;
	const char *src = "Vl";
	char	*dst;

	dst = malloc(sizeof(char) * 8);
	printf("%s",ft_strncpy(dst, src, len));
	printf("%d",(int)dst[3]);
	return (0);
}
