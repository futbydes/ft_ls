/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strchr.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/28 18:27:07 by vludan            #+#    #+#             */
/*   Updated: 2017/11/03 16:53:25 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

char	*ft_strrchr(const char *s, int c)
{
	char	*x;
	int		y;

	x = 0;
	y = 0;
	while (*s != '\0')
	{
	   if (*s == (char)c)
		   x = (char*)s;
	   s++;
	}
	if (*s == '\0' && (char)c == '\0')
	{
		x = (char*)s;
		return (x);
	}
	else
		return (x);
}

int		main(void)
{
	static char buf[] = "abcdedcba";
	int	c = 'x';
	char	p,p1;


	if (strrchr(buf, c) == ft_strrchr(buf, c))
		printf("%d",2);
//	p = printf("ORG: %s",ft_strrchr(buf,c));
//	p1 = printf("ORG: %s",strrchr(buf,c));
//	if (p == p1)
//		printf("%d",1);
	return (0);
}
