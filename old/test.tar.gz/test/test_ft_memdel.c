/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memdel.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/29 16:13:36 by vludan            #+#    #+#             */
/*   Updated: 2017/10/29 18:18:21 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>

void	ft_memdel(void **ap)
{
	free(*ap);
	*ap = NULL;
}

/* A block of memory previously allocated using a call to malloc, calloc or realloc is deallocated, making it available again for further allocations. Notice that this function leaves the value of ptr unchanged, hence it still points to the same (now invalid) location, and not to the null pointer. */

int		main(void)
{
	void	 **ap;

	*ap = malloc(10);
	printf("%p - %p\n", ap, *ap);
	ft_memdel(ap);
	printf("$- %p - %p\n", ap, *ap);
	return (0);
}
