/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/27 15:47:17 by vludan            #+#    #+#             */
/*   Updated: 2017/10/27 16:01:31 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int		ft_memcmp(const void *s1, const void *s2, size_t n)
{
	int		x;
	int		y;
	int		z;

	x = n;
	z = 0;
	y = 0;
	while ((y != x) && (z == 0))
	{
		z = ((unsigned char*)s1)[y] - ((unsigned char*)s2)[y];
		y++;
	}
	return (z);
}

int		main(void)
{
	const void *s1 = "\200";
	const void *s2 = "\0";
	size_t n = 5;
	int	z;

	z = ft_memcmp(s1,s2,n);
	printf("%d",z);
	return (0);
}
