/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstnew.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/31 14:53:05 by vludan            #+#    #+#             */
/*   Updated: 2017/11/02 15:47:40 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

void    del(char *s, size_t o) // del change elem;
{
	int     x;

	(void)o;	
	x = 0;
	while (*s != '\0')
		*s++ = '0';

}

static int	len_s(char *s)
{
	int		x;

	x = 0;
	while (s[x] != '\0')
		x++;
	return (x);
}

void	f(t_list *elem)
{
		printf("%s",elem->content);
}


void    ft_lstdelone(t_list **alst, void (*del)(char*, size_t))
{
	del((*alst)->content, (*alst)->content_size);
	free(*alst);
	*alst = NULL;
}

void	ft_lstadd(t_list **alst, t_list *new)
{
	new->next = (*alst);
	(*alst) = new;
}

t_list		*ft_lstnew(char *content, size_t content_size)
{
	t_list	*new;

	new = (t_list*)malloc(sizeof(t_list));
	new->content = malloc(len_s(content) + 1);
	new->content_size = content_size;
	ft_memcpy(new->content, content, len_s(content) + 1);
	if (content == 0)
		new->content_size = 0;
	new->next = 0;
	return (new);
}

void	ft_lstiter(t_list *lst, void (*f)(t_list *elem))
{
	while (lst != 0)
	{
		f(lst);
		lst = lst->next;
	}
}

int		main(void)
{
	char	*content = "sasa";
	size_t	content_size = 4;
	t_list	*p = NULL;
	t_list	*alst = NULL;

	p = ft_lstnew(content,content_size);
	printf("%s\n",p->content);
	content = "wtffe";
	alst = ft_lstnew(content,content_size);
	printf("%s\n",alst->content);
	ft_lstadd(&alst, p);
//	f(alst);
	ft_lstiter(alst, f);
//	printf("1%p 2%p",p->next, alst);
//	ft_lstdelone(&p, *del);
//	printf("%s\n",p->content);
	return (0);
}
