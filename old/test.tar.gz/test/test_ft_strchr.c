/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strchr.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/28 18:27:07 by vludan            #+#    #+#             */
/*   Updated: 2017/10/28 18:52:33 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>

char	*ft_strchr(const char *s, int c)
{
	int		x;

	while ((*s != (char)c) && (*s != '\0'))
		s++;
	if (*s != (char)c)
		return (0);
	return ((char *)s);
}

int		main(void)
{
	const char *s = "valiovl";
	int	c = '\0';
	printf("%s%s",ft_strchr(s,c),"\n");
	printf("%s%s",strchr(s,c),"\n");
	printf("%s",strrchr(s,c));
	return (0);
}
