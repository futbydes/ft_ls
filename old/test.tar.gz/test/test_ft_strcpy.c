/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/27 17:16:19 by vludan            #+#    #+#             */
/*   Updated: 2017/10/27 17:40:59 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strcpy(char *dst, const char *src)
{
	int		x;
	char	*temp;

	temp = dst;
	while ((*dst++ = *src++) != '\0');
	return (temp);
}

int		main(void)
{
	const char *src;
	char *dst;
	
	dst = malloc(sizeof(char) * 3);
	src = "dsdsds";
	printf("%s",ft_strcpy(dst,src));
	return (0);
}
