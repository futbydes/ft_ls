/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/27 11:28:03 by vludan            #+#    #+#             */
/*   Updated: 2017/11/01 18:12:49 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memcpy(void *dst, const void *src, size_t n)
{
	int		x;
	int		y;
	void	*temp;

	x = n;
	y = 0;
	temp = dst;
	while (y != x)
	{
		((unsigned char*)dst)[y] = ((unsigned char*)src)[y];
		y++;
	}
	return (temp);
}

int		main(void)
{
	const void *src = "BLSDDLS\0SSAA";
	void *dst;

	dst = malloc(sizeof(char) * 8);
	ft_memcpy(dst,src,4);
	printf("%s",(char*)dst);
	return (0);
}
