/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnew.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/29 16:40:13 by vludan            #+#    #+#             */
/*   Updated: 2017/11/03 17:52:32 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

char	*ft_strnew(size_t size)
{
	char	*s;
	size_t		x;

	s = (char*)malloc(sizeof(char) * size);
	if (s == NULL)
		return (NULL);
	x = 0;
	while (x < size)
		s[x++] = 0;
	return (s);
}

int		main(void)
{
	size_t	size = 2;
	char	*str;
	char	*t;
	int		i;


	printf("%s\n",ft_strnew(size));
	str = ft_strnew(100);
	t = malloc(101);
	bzero(t, 101);
	i = memcmp(str, t, 101);
	printf("%d",i);
	return (0);
}
