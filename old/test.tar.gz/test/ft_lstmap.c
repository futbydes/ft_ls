/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/06 14:31:33 by vludan            #+#    #+#             */
/*   Updated: 2017/11/06 20:36:41 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

t_list  *f(t_list *list)
{
	t_list  *l2;

	l2 = malloc(sizeof(t_list));
	bzero(l2, sizeof(t_list));
	l2->content = malloc(list->content_size * 2);
	l2->content_size = list->content_size * 2;
	return (l2);
}

t_list	*ft_lstmap(t_list *lst, t_list *(*f)(t_list *elem))
{
	t_list	*new;
	t_list	*head;

	if (lst == 0 || f == 0)
		return (0);
	new = f(lst);
	head = new;
	if (new == 0)
		return (0);
	while (lst->next)
	{
		lst = lst->next;
		new->next = f(lst);
		if (new->next == 0)
			return (head);
		new = new->next;
	}
	return (head);
}

int		main(void)
{
	t_list  *list;
	t_list  *map;

	bzero((list = malloc(sizeof(t_list))), sizeof(t_list));
	bzero((list->next = malloc(sizeof(t_list))), sizeof(t_list));
	bzero((list->next->next = malloc(sizeof(t_list))), sizeof(t_list));
	list->content_size = 21;
	list->content = strdup("abc");
	list->next->content_size = 100;
	list->next->content = strdup("abc");
	list->next->next->content_size = 150;
	list->next->next->content = strdup("abc");
	map = ft_lstmap(list, f);
	printf("%zu\n", map->content_size);
	printf("%zu\n", map->next->content_size);
	printf("%zu\n", map->next->next->content_size);
}
