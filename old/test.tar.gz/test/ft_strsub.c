/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strsub.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/30 13:15:22 by vludan            #+#    #+#             */
/*   Updated: 2017/10/31 18:37:12 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strsub(char const *s, unsigned int start, size_t len)
{
	char			*a;
	unsigned int	x;
	unsigned int	z;

	x = 0;
	z = 0;
	a = malloc(sizeof(char) * (len));
	while ((s[start] != '\0') && (len != 0))
	{
		a[z++] = s[start++];
		len--;
	}
	return (a);
}
