/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memalloc.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/29 15:24:20 by vludan            #+#    #+#             */
/*   Updated: 2017/11/01 15:13:12 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memalloc(size_t size)
{
	void	*area;
	void	*h;

	area = malloc(size);
	h = area;
	while (size != 0)
	{
		*(unsigned char*)area++ = 0;
		size--;
	}
	return (h);
}
