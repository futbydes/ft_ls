/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstadd_end.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/05 18:51:33 by vludan            #+#    #+#             */
/*   Updated: 2017/11/05 20:58:08 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

t_list		**ft_lstadd_end(t_list *node, t_list **list)
{
	t_list		*head;

	head = *list;
	if (node == 0 || list == 0)
		return (0);
	while ((*list)->next != NULL)
		(*list) = (*list)->next;
	(*list)->next = node;
	node->next = 0;
	(*list) = head;
	return (list);
}

int		ft_lstprint(t_list	*list)
{
	if (list == 0)
		return (0);
	ft_putstr(":START:\n");
	while (list->next != NULL)
	{
		ft_putstr(list->content);
		ft_putchar('\n');
		list = list->next;
	}
	ft_putstr(list->content);
	ft_putstr(":END:");
	return (0);
}

t_list		*ft_lstdel_sn(t_list *list)
{
	t_list	*head;

	if (list == 0)
		return (0);
	head = list->next;
	free(list);
	list = head;
	return (list);
}

t_list		*ft_lstdel_en(t_list *list)
{
	t_list	*head;

	if (list == 0)
		return (0);
	head = list;
	while (list->next->next != 0)
		list = list->next;
	free(list->next);
	list->next = 0;
	list = head;
	return (head);
}

t_list		*ft_lstdel_id(t_list *list, int id)
{
	int		d;
	t_list	*temp;
	t_list	*head;

	d = 0;
	if (list == 0 || id < 0)
		return (0);
	if (id == 0)
		return (ft_lstdel_sn(list));
	head = list;
	while (d < (id - 1) && list->next != 0)
	{
		list = list->next;
		d++;
	}
	if (d == (id - 1))
	{
		temp = list->next;
		list->next = temp->next;
		free(temp);
	}
	return (head);
}
	
int		main(void)
{
	t_list		*p1,*p2,*p3,*node,*str;

	p1 = ft_lstnew("abrac",6);
	p2 = ft_lstnew("abracd",6);
	p3 = ft_lstnew("abracdbra",6);
	p1->next = p2;
	p2->next = p3;
	p3->next = 0;
	node = ft_lstnew("dsadsa",6);
	ft_lstadd_end(node, &p1);
	ft_lstprint(p1);
	ft_lstdel_id(p1, 2);
//	str = ft_lstdel_en(p1);
//	printf("%s",str->content);
//	ft_lstdel_sn(p1);
//	str = ft_lstdel_en(p1);
	ft_lstprint(p1);
	return (0);
}
