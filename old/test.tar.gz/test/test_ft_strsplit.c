/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strsplit.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/30 15:25:56 by vludan            #+#    #+#             */
/*   Updated: 2017/11/05 14:33:22 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

static int		len(char const *s, char c)
{
	int			count;
	int		x;

	x = 0;
	count = 0;
	if (s[x] == '\0')
		return (count);
	while ((s[x] == c) && (s[x] != '\0'))
		x++;
	while ((s[x] != c) && (s[x] != '\0'))
	{
		count++;
		x++;
	}
	return (count);
}

static int		main_len(char const *s)
{
	int			x;

	x = 0;
	while (s[x] != '\0')
		x++;
	return (x);
}

static char		**stringalloc(const char **s, int z, char c, char **arr)
{
	int			y;

	y = 0;
	arr[z] = (char*)malloc(sizeof(char*) * len(*s, c) + 1);
	if (arr[z] == 0)
		free(arr);
	if (*s != '\0')
	{
		while ((**s != c) && (**s != '\0'))
			arr[z][y++] = *(*s)++;
	}
	arr[z][y] = '\0';
	return (arr);
}

char			**ft_strsplit(char const *s, char c)
{
	int			z;
	char		**arr;

	if ((s == 0) || (c == 0))
		return (0);
	z = 0;
	arr = (char**)malloc(sizeof(char*) * main_len(s));
	if (arr == 0)
		return (0);
	while (*s != '\0')
	{
		while (*s != '\0' && *s == c) 
			s++;
		if (*s != '\0')
		{
			stringalloc(&s, z, c, arr);
			z++;
		}
	}
	arr[z] = 0;
	return (arr);
}

int		main(void)
{
//	char const s[] = "split  ||this|for|me|||||!|";
	char c = 's';
	char	**p;

	char *s = "      split       this for   me  !       ";
	p = ft_strsplit(s, c);
	
	//printf("%d",strcmp(ft_strsplit(s, ' '), *ret))
	printf("%s",p[0]);
	printf("%s",p[1]);
	printf("%s",p[2]);
	printf("%s",p[3]);
	printf("%s",p[4]);
	printf("%s",p[5]);
	printf("%s",p[6]);
	printf("%s",p[7]);
	printf("%s",p[28]);
	printf("%s",p[38]);
	printf("%s",p[138]);
	return (0);
}
