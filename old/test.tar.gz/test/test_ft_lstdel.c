/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstdel.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/31 19:04:51 by vludan            #+#    #+#             */
/*   Updated: 2017/11/01 13:34:54 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

t_list		*ft_lstnew(char	*content, size_t content_size)
{
	t_list	*new;

	new = (t_list*)malloc(sizeof(t_list));
	new->content = (void*)content;
	new->content_size = content_size;
	if (content == 0)
		content_size = 0;
	new->next = NULL;
	return (new);
}


void	ft_lstdel(t_list **alst) //void (*del)(void *,size_t))
{
	void	*temp;

	while ((*alst) != 0)
	{
//		del((*alst)->content, (*alst)->content_size);
		temp = *alst;
		*alst = (*alst)->next;
		free(temp);
		printf("%s","1");
	}
	*alst = NULL;
}

int		main(void)
{
	char	*content = "pdcz";
	size_t	content_size = 4;
	t_list	*p;
	t_list	*s;

	p = ft_lstnew(content,content_size);
	printf("%s",p->content);
	content = "cl";
	content_size = 10;
	s = ft_lstnew(content, content_size);
	printf("%s",s->content);
	p->next = s;
	ft_lstdel(&p);
//	printf("%s",p->content);
//	printf("%s",s->content);
	return (0);
}
