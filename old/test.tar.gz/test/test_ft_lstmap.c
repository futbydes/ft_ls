/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/01 13:53:19 by vludan            #+#    #+#             */
/*   Updated: 2017/11/02 15:18:57 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>
#include <stdio.h>

t_list  *f(t_list *list)
{
	t_list  *l2;

	l2 = malloc(sizeof(t_list));
	bzero(l2, sizeof(t_list));
	l2->content = malloc(list->content_size * 2);
	l2->content_size = list->content_size * 2;
	return (l2);
}

t_list		*ft_lstmap(t_list *lst, t_list *(*f)(t_list *elem))
{
	t_list	*new;

	if (lst->next != 0)
	{
		if ((new = f(lst)))
			new->next = ft_lstmap(lst->next, f);
		else
			return (0);
	}
	else
	{
		if ((new = f(lst)))
			new->next = 0;
		else
			return (0);
	}
	return (new);
}

int		main(void)
{
	char	*content = "xsss";
	size_t		content_size = 5;
	t_list		*s;
	t_list		*y;
	t_list		*z;


	s = ft_lstnew(content, content_size);
	printf("%s\n",s->content);
	content = "dssss";
	y = ft_lstnew(content, content_size);
	printf("%s\n",y->content);
	content = "ossss";
	z = ft_lstnew(content, content_size);
	printf("%s\n",z->content);
	printf("%zu\n",z->content_size);
	ft_lstadd(&s, y);
	printf("addr: %p\n",s);
	ft_lstadd(&y, z);
	printf("%p -> %p -> %p\n",s->next,y->next,z->next);
	printf("%p -> %p -> %p\n",s,y,z);
	ft_lstmap(z, f);	
	printf("%zu\n",s->content_size);
	return (0);
}
