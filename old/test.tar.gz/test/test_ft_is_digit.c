/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isdigit.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/29 13:43:06 by vludan            #+#    #+#             */
/*   Updated: 2017/10/29 13:48:33 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ctype.h>
#include "libft.h"

int		ft_isdigit(int	c)
{
	if ((c >= '0') && (c <= '9'))
		return (1);
	else
		return (0);
}

int		main(void)
{
	int		c = '\n';

	printf("%d",isdigit(c));
	printf("%d",ft_isdigit(c));
	return (0);
}
