/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strsplit.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/30 15:25:56 by vludan            #+#    #+#             */
/*   Updated: 2017/11/05 12:48:50 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>
/*
static int		len(char const *s, int x, char c)
{
	int			count;
	int			temp;

	count = 0;
	temp = x;
	if (s[x] == '\0')
		return (count);
	while ((s[x] == c) && (s[x] != '\0'))
		x++;
	while ((s[x] != c) && (s[x] != '\0'))
	{
		count++;
		x++;
	}
	x = temp;
	return (count);
}
*/
static int		len(char const *s, char c)
{
	int		count;
	char	*tmp;

	count = 0;
	tmp = (char*)s;
	if (*s == '\0')
		return (count);
	while (*s == c && *s != '\0')
		s++;
	while (*s != c && *s != '\0')
	{
		count++;
		s++;
	}
	s = tmp;
	return (count);
}
/*
static int		main_len(char const *s, char c)
{
	int			x;
	int			g;

	x = 0;
	g = 0;
	while (s[x] != '\0')
	{
		while ((s[x] == c) && (s[x] != '\0'))
			x++;
		while ((s[x] != c) && (s[x] != '\0'))
			x++;
	}
	g = x;
	return (g);
}
*/
static int		main_len(char const *s)
{
	int		n;
	char	*temp;

	n = 0;
	temp = (char*)s;
	while (*s != '\0')
	{
		n++;
		s++;
	}
	s = temp;
	return (n);
}

char			**ft_strsplit(char const *s, char c)
{
	char		**arr;
	char		**temp;

	if (s == 0 || c == 0)
		return (0);
	temp = arr;
	arr = (char**)malloc(sizeof(char*) * main_len(s));
	if (arr == 0)
		return (0);
	while (*s != '\0')
	{
		while ((*s == c) && (*s != '\0'))
			s++;
		*arr = (char*)malloc(sizeof(char) * len(s, c) + 1);
		printf("%d",1);
		if (*arr == 0)
			free(*arr);
		if (*s != '\0')
		{
			while ((*s != c) && (*s != '\0'))
			{
				printf("%c",*s);
				**arr++ = *s++;
			//	printf("%c",**arr);
			}
			**arr = '\0';
			(*arr)++;
		}
	}
	*arr = 0;
	return (temp);
}

int		main(void)
{
	char const	s[] = "dsadxads";
	char		c = 'a';
	char		**p;


	printf("%d\n",main_len(s));
	printf("%d\n",len(s ,c));
p = ft_strsplit(s, c);
	printf("%s",p[0]);
//	printf("%s",p[1]);
//	printf("%s",p[2]);
	return (0);
}

