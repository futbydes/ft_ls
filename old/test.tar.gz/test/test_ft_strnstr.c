/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/28 19:06:39 by vludan            #+#    #+#             */
/*   Updated: 2017/11/04 15:52:37 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

char	*ft_strnstr(const char *big, const char *little, size_t len)
{
	char	*temp;
	size_t	tmp;
	int		x;
	int		i;

	if (*little == '\0')
		return ((char*)big);
	while (((temp = (char*)big)) && (len) && *big != '\0')
	{
		i = 0;
		x = 0;
		tmp = len;
		while ((little[i++] == big[x++]) && (tmp))
		{
			if (little[i] == '\0')
				return (temp);
			tmp--;
		}
		big++;
		len--;
	}
	return (big);
}

int		main(void)
{
	char	buf[10];
	int		c;

//	bzero(buf,11);
	strcpy(buf, "un deax 9");
	buf[9] = '6';
	buf[1] = 0;
	printf("%s",buf);
//	strcmp(ft_strnstr(buf, "x", 10), "6");
	printf("MY: %s\n",ft_strnstr(buf,"deax",10));
	printf("ORIG: %s",strnstr(buf,"deax",10));
	return (0);
}
