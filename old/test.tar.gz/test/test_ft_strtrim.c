/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/30 14:16:03 by vludan            #+#    #+#             */
/*   Updated: 2017/11/04 15:37:43 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

static int	len_white(const char *s)
{
	int		x;
	int		w;

	x = 0;
	while (s[x] != '\0')
		x++;
	x--;
	while ((s[x] == ' ') || (s[x] == '\n') || (s[x] == '\t'))
	{
		x--;
		if (x == 0)
			return (0);
	}
	w = x;
	x = 0;
	while ((s[x] == ' ') || (s[x] == '\n') || (s[x] == '\t'))
		x++;
	w -= x;
	return (w + 1);
}


char	*ft_strtrim(char const *s)
{
	char	*m;
	int		x;
	int		y;

	y = 0;
	x = 0;
	if (*s == 0)
		return ((char*)s);
	m = (char*)malloc(sizeof(char) * len_white(s + 1));
	if (s[x] == '\0')
	{
		m[x] = '\0';
		return (m);
	}
	while ((s[x] == ' ') || (s[x] == '\n') || (s[x] == '\t'))
		x++;
	while ((len_white(s) > y) && (s[x] != '\0'))
	{
		m[y++] = s[x++];
		printf("LEN %d Y %d\n",len_white(s), y);
	}
	m[y] = '\0';
	printf("%s",m);
	return (m);
}

int		main(void)
{
	const char s[1] = "";

	printf("%d", strcmp(ft_strtrim("abc"), "abc"));
	return (0);
}
