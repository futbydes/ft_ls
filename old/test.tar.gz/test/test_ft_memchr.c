/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/27 14:34:30 by vludan            #+#    #+#             */
/*   Updated: 2017/11/04 17:52:10 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

void		*ft_memchr(const void *s, int c, size_t n)
{
	while (n-- != 0)
	{
		if (*(unsigned char*)s == (unsigned char)c)
			return ((void*)s);
		s++;
	}
	return (0);
}

int		main(void)
{
	char	*s,*s1;

	printf("%s",(char*)ft_memchr(((void*)0), '\0', 5));
//	printf("%s",(char*)memchr(((void*)0), '\0', 5));
	return (0);
}
