/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/27 11:28:03 by vludan            #+#    #+#             */
/*   Updated: 2017/11/01 20:34:08 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memcpy(void *dst, const void *src, size_t n)
{
	int		x;
	int		y;

	x = n;
	y = 0;
	while (y != x)
	{
		((unsigned char*)dst)[y] = ((unsigned char*)src)[y];
		y++;
	}
	return (dst);
}
