/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/28 12:53:12 by vludan            #+#    #+#             */
/*   Updated: 2017/11/02 13:12:21 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strncat(char *s1, const char *s2, size_t n)
{
	size_t		c;
	int		x;

	c = 0;
	x = 0;
	while (s1[x] != '\0')
		x++;
	while ((c != n) && (*s2 != '\0'))
	{
		s1[x++] = *s2++;
		c++;
	}
	s1[x] = '\0';
	return (s1);
}

int		main(void)
{
	const char	*s2 = "luv";
	char s1[100] = "make";

	printf("%s",ft_strncat(s1, s2, 2));
	return (0);
}
