/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memccpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/27 12:19:29 by vludan            #+#    #+#             */
/*   Updated: 2017/11/04 20:32:52 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>
#include <stdio.h>

void	*ft_memccpy(void *dst, const void *src, int c, size_t n)
{
	int		y;
	int		z;
	void	*temp;

	z = n;
	y = 0;
	temp = dst;
	while (y != z)
	{
		if ((*(unsigned char*)src) == (unsigned char)c)
		{
			*(unsigned char*)dst = *(unsigned char*)src;
			return (dst);
		}
		*(unsigned char*)dst++ = *(unsigned char*)src++;
		y++;
	}
	return (0);
}

int		main(void)
{
	char	src[] = "test basic du memccpy !";
	char	dst[200];
	char	xdst[200];
	int		c = 'm';
	size_t	s = 0;


	memccpy("",src,c,s);
	ft_memccpy("",src,c,s);
	if (memccpy("",src,c,s) == ft_memccpy("",src,c,s))
		printf("%d\n",1);
	printf("ORIG: %s\n",xdst);
	printf("  MY: %s\n",dst);
	return (0); 
}	
