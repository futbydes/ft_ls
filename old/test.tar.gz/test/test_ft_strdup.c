/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/27 16:52:58 by vludan            #+#    #+#             */
/*   Updated: 2017/10/27 17:30:57 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>

char	*ft_strdup(const char *s1)
{
	int		y;
	int		x;
	char	*s2;

	y = 0;
	x = ft_strlen(s1);
	s2 = (char*)malloc(sizeof(char) * x);
	while (s1[y] != '\0')
	{
		s2[y] = s1[y];
		y++;
	}
	s2[y] = '\0';
	return (s2);
}

int		main(void)
{
	const char *s1;

	s1 = "dsdsd";
	printf("%s",ft_strdup(s1));
	printf("%s",strdup(s1));
	return (0);
}
