/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/28 19:06:39 by vludan            #+#    #+#             */
/*   Updated: 2017/10/28 20:26:36 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>

char	*ft_strstr(const char *big, const char *little)
{
	char	*temp;
	int		x;
	int		i;

	x = 0;
	i = 0;
	while (big[x] != '\0')
	{
		temp = (char*)big;
		while ((little[i] == big[x]) || (little[i] == '\0'))
		{
			if ((little[i] == '\0') || (big[x] == '\0'))
				return (temp);
			x++;
			i++;
		}
		x = 0;
		big++;
		i = 0;
	}
	return (0);
}
