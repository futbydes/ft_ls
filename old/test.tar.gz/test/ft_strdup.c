/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/27 16:52:58 by vludan            #+#    #+#             */
/*   Updated: 2017/10/28 17:31:46 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static	int	len(const char *c)
{
	int		i;

	i = 0;
	while (c[i] != '\0')
		i++;
	return (i);
}

char		*ft_strdup(const char *s1)
{
	int		y;
	int		x;
	char	*s2;

	y = 0;
	x = len(s1);
	s2 = (char*)malloc(sizeof(char) * x);
	while (s1[y] != '\0')
	{
		s2[y] = s1[y];
		y++;
	}
	s2[y] = '\0';
	return (s2);
}
