/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/28 19:05:39 by vludan            #+#    #+#             */
/*   Updated: 2017/10/28 19:06:20 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>

char	*ft_strrchr(const char *s, int c)
{
	char	*x;

	while (*s != '\0')
	{
		if (*s == (char)c)
			x = (char *)s;
		s++;
	}
	if ((char)c == '\0')
		return ("\0");
	if (*x == (char)c)
		return (x);
	else
		return (0);
}
