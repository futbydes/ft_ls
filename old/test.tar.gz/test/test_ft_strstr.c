/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/28 19:06:39 by vludan            #+#    #+#             */
/*   Updated: 2017/11/03 17:38:50 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

char	*ft_strstr(const char *big, const char *little)
{
	char	*temp;
	int		x;
	int		i;

	if (big[x] == '\0' && little[x] == '\0')
		return ((char*)big);
	while (big[x] != '\0')
	{
		x = 0;
		i = 0;
		temp = (char*)big;
		while ((little[i] == big[x]) || (little[i] == '\0'))
		{
			if ((little[i] == '\0') || (big[x] == '\0'))
				return (temp);
			x++;
			i++;
		}
		big++;
	}
	return (0);
}

int		main(void)
{
	char *s1 = "Ceci n'est pas une pipe.";
	char *s2 = "aaaaa";

	if (ft_strstr(s1,s2) == strstr(s1,s2))
		printf("%d",1);
	return (0);
}
