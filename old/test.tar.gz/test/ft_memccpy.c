/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memccpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/27 12:19:29 by vludan            #+#    #+#             */
/*   Updated: 2017/10/29 19:16:34 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>

void	*ft_memccpy(void *dst, const void *src, int c, size_t n)
{
	int		x;
	int		y;
	int		z;

	z = n;
	y = 0;
	x = 0;
	while (y != z)
	{
		((unsigned char*)dst)[x] = *(unsigned char*)src++;
		if (((unsigned char*)dst)[x] == (unsigned char)c)
		{
			((unsigned char*)dst)[x + 1] = '\0';
			return (0);
		}
		x++;
		y++;
	}
	return (dst);
}
