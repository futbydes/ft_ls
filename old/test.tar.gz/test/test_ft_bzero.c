/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/27 10:46:15 by vludan            #+#    #+#             */
/*   Updated: 2017/10/28 17:52:56 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void		ft_bzero(void	*s, size_t n)
{
	int		x;
	int		y;

	x = n;
	y = 0;
	while ((y < x) && (x != 0))
	{
		*(unsigned char*)s++ = 65;
		y++;
		printf("%s","dva");
	}
}

int		main(void)
{
	void	*n;

	n = malloc(sizeof(char) * 8);
	ft_bzero(n,3);
	printf("%s",(char*)n);
	return (0);
}
