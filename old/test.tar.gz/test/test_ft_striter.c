/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_striter.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/29 19:47:42 by vludan            #+#    #+#             */
/*   Updated: 2017/10/30 11:27:36 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	rem(char *c)
{
	if (*c == 'S')
		printf("%d",1);
	else
		printf("%d",0);
}

void	ft_striter(char *s, void (*rem)(char *))
{
	while (*s != '\0')
		rem(s++);
}

int		main(void)
{
	char	s[20] = "SASAS";

	ft_striter(s,rem);
	printf("%s",s);
	return (0);
}
