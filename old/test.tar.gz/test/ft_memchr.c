/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/27 14:34:30 by vludan            #+#    #+#             */
/*   Updated: 2017/11/04 14:41:37 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

void		*ft_memchr(const void *s, int c, size_t n)
{
	int		x;
	int		y;

	if ((unsigned char*)s == 0 || n == 0)
		return (0);
	y = n;
	x = 0;
	while (x++ != y && (*(unsigned char*)s != (unsigned char)c))
		s++;
	if (*(unsigned char*)s == (unsigned char)c)
		return ((void*)s);
	else
		return (0);
}

int		main(void)
{
	if (ft_memchr("abcdef", 'a', 5) == memchr("abcdef", 'a', 5))
			printf("1- %d",1);
	if (ft_memchr("abcdef", 'c', 5) == memchr("abcdef", 'c', 5))
			printf("2- %d",1);
	if (ft_memchr("abcdef", '\0', 7) == memchr("abcdef", '\0', 7))
			printf("3- %d",1);
	if (ft_memchr("abcdef", 'z', 6) == memchr("abcdef", 'z', 6))
			printf("4- %d",1);
	if (ft_memchr("abcdef", 999, 6) == memchr("abcdef", 999, 6))
			printf("5-%d",1);
	return (0);
}
