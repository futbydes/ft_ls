/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strequ.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/30 12:40:12 by vludan            #+#    #+#             */
/*   Updated: 2017/10/30 12:50:33 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int		ft_strequ(char const *s1, char const *s2)
{
	int		x;

	x = 0;
	while ((s1[x] - s2[x] == 0) && ((s1[x] != '\0') || (s2[x] != '\0')))
		x++;
	if ((s1[x] == s2[x]) || ((s1[x] == '\0') && (s2[x] == '\0')))
		return (1);
	else
		return (0);
}

int		main(void)
{
	char const	s1[20] = "";
	char const	s2[20] = "";

	printf("%d",ft_strequ(s1,s2));
	return (0);
}
