/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnew.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/29 16:40:13 by vludan            #+#    #+#             */
/*   Updated: 2017/11/01 15:46:17 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnew(size_t size)
{
	char		*s;
	size_t		x;

	s = (char*)malloc(sizeof(char) * size);
	if (s == NULL)
		return (NULL);
	x = 0;
	while (x < size)
		s[x++] = 'b';
	return (s);
}
