/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/27 18:10:30 by vludan            #+#    #+#             */
/*   Updated: 2017/10/28 12:51:44 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strcat(char *s1, const char *s2)
{
	int		x;

	x = 0;
	while (s1[x] != '\0')
		x++;
	while (*s2 != '\0')
		s1[x++] = *s2++;
	s1[x] = '\0';
	return (s1);
}

int		main(void)
{
	const char *s2 = "blabla";
	char s1[100] = "dsd";

	printf("%s",ft_strcat(s1, s2));
	return (0);
}
