/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnequ.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/30 12:51:19 by vludan            #+#    #+#             */
/*   Updated: 2017/11/03 09:38:58 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

int		ft_strnequ(char const *s1, char const *s2, size_t n)
{
	size_t		x;

	x = 0;
	while (((s1[x] == s2[x]) != '\0') && (x < n - 1))
		x++;
	if ((s1[x] == s2[x]) || ((s1[x] == '\0') && (s2[x] == '\0')) || (n == 0))
		return (1);
	else
		return (0);
}

int		main(void)
{
	char const	s1[10] = "ededeqdf";
	char const	s2[10] = "";

	printf("%d", ft_strnequ(s1,s2,0));
	return (0);
}
