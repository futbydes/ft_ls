/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/24 15:26:18 by vludan            #+#    #+#             */
/*   Updated: 2017/10/24 16:00:06 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		*ft_range(int min, int max)
{
	int		x;
	int		*str;
	int		y;

	y = 0;
	if (min >= max)
		return (0);
	x = max - min;
	str = malloc(sizeof(int) * x);	
	while (min <  max)
		str[y++] = min++;
	return (str);
}
