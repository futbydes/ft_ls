/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/23 18:00:00 by vludan            #+#    #+#             */
/*   Updated: 2017/10/23 18:04:56 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_is_negative(int n);

int		main(void)
{
	int		c;

	c = -1;
	ft_is_negative(c);
	return (0);
}

void	ft_putchar(char c)
{
	write(1,&c,1);
}

void	ft_is_negative(int n)
{
	if (n >= 0)
		ft_putchar('P');
	if (n < 0)
		ft_putchar('N');
}
