/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/24 10:28:11 by vludan            #+#    #+#             */
/*   Updated: 2017/10/24 13:05:35 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int		ft_strcmp(char *s1, char *s2);

int		main(void)
{
	char 	*s1;
	char	*s2;

	s1 = "ahuysa";
	s2 = "Zuysad";
	printf("%d",ft_strcmp(s1,s2));
	return (0);
}

int		ft_strcmp(char *s1, char *s2)
{
	int		n;

	n = 0;
	while ((s1[n] == s2[n]) && (s1[n] != '\0') && (s2[n] != '\0'))
		n++;
	if ((s1[n] == '\0') && (s2[n] == '\0'))
		return (0);
	if (s1[n] == '\0')
		return (0 - s2[n]);
	if (s2[n] == '\0')
		return (s1[n]);
	if (s1[n] > s2[n])
		return (s1[n] - s2[n]);
	if (s1[n] < s2[n])
		return (s1[n] - s2[n]);
	return (0);
}
