/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_display_file.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/26 12:15:52 by vludan            #+#    #+#             */
/*   Updated: 2017/10/26 13:44:18 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define BUF_SIZE 4096

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	int		x;

	x = 0;
	while (str[x] != '\0')
		ft_putchar(str[x++]);
}

int		main(int argc, char **argv)
{
	int		fd;
	int		ret;
	char	buf[BUF_SIZE + 1];

	fd = open(argv[1], O_RDONLY);
	if (argc > 2)
	{
		ft_putstr("Too many arguments.");
		return (0);
	}
	if (fd == -1)
	{
		ft_putstr("File name missing.");
		return (0);
	}
	read(fd, buf, BUF_SIZE);
	ft_putstr(buf);
	close(fd);
	return (0);
}
