#include <stdio.h>
#include "ft_abs.h"

int		main(void)
{
	printf("%d",ABS(-7));
	return(0);
}
