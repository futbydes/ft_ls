/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   strdup.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/24 14:45:36 by vludan            #+#    #+#             */
/*   Updated: 2017/10/24 15:23:45 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int		ft_strlen(char *src)
{
	int		x;

	x = 0;
	while (src[x] != '\0')
		x++;
	return (x);
}

char	*ft_strdup(char *src)
{
	int		x;
	char	*y;

	x = 0;
	y = malloc(sizeof(char) * ft_strlen(src));
	while (src[x] != '\0')
	{
		y[x] = src[x];
		x++;
	}
	return (y);
}

int		main(void)
{
	char	*y;

	y = "fdsfd";
	printf("%s",ft_strdup(y));
	return (0);
}
