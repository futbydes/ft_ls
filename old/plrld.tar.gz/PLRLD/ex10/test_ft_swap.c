/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/23 18:31:44 by vludan            #+#    #+#             */
/*   Updated: 2017/10/23 18:41:25 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int		ft_swap(int *a,int *b);

int		main(void)
{
	int		a;
	int		b;

	a = 7;
	b = 9;
	ft_swap(&a,&b);
	printf("%d",b);
	return (0);
}

int		ft_swap(int *a,int *b)
{
	int		c;

	c = *b;
	*b = *a;
	*a = c;
	return (*b);
}

