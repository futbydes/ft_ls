/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/23 20:31:23 by vludan            #+#    #+#             */
/*   Updated: 2017/10/26 15:08:36 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int		ft_recursive_factorial(int nb)
{
	if ((nb == 1) || (nb == 0))
		return (1);
	if ((nb < 0) || (nb > 12))
		return (0);
	else
		return (nb * ft_recursive_factorial(nb - 1));
}

int		main(void)
{
	int		nb;
	int		n;

	nb = 0;
	n = ft_recursive_factorial(nb);
	printf("%d", n);
	return (0);
}
