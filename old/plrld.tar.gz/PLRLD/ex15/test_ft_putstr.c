/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/24 10:07:32 by vludan            #+#    #+#             */
/*   Updated: 2017/10/24 11:39:51 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	int		n;

	n = 0;
	while (str[n] != '\0')
		ft_putchar(str[n++]);
}

int		main(void)
{
	char	*str;

	str = "blya434sta";
	ft_putstr(str);
	return (0);
}
