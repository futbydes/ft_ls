/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/24 10:14:29 by vludan            #+#    #+#             */
/*   Updated: 2017/10/24 10:25:07 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	int		n;

	n = 0;
	while (str[n] != '\0')
		ft_putchar(str[n++]);
}

int		ft_strlen(char *str)
{
	int		count;
	int		n;

	count = 0;
	n = 0;
	while (str[n] != '\0')
	{
		n++;
		count++;
	}
	return (count);
}

int		main(void)
{
	char	*str;

	str = "tut7buk";
	printf("%d",ft_strlen(str));
	return (0);
}

