/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vludan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/24 12:16:14 by vludan            #+#    #+#             */
/*   Updated: 2017/10/24 14:16:55 by vludan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int		ft_strcmp(char *s1,char *s2)
{
	while (*s1 != '\0' || *s2 != '\0')
	{
		if (*s1 != *s2)
			return (*s1 - *s2);
		s1++;
		s2++;
	}
	return (0);
}

void	ft_putstr(char	*s)
{
	int		x;

	x = 0;
	while (s[x] != '\0')
	{
		ft_putchar(s[x]);
		x++;
	}
}

void	ft_printarray(int argc,char **argv)
{
	int		i;

	i = 1;
	while (i < argc) 
	{
		ft_putstr(argv[i++]);
		ft_putchar('\n');
	}
}

int		main(int argc, char **argv)
{
	int		x;
	int		z;
	char	*y;

	z = 1;
	while (z < argc)
	{
		x = 1;
		while (x < (argc - 1))
		{
			if (ft_strcmp(argv[x],argv[x + 1]) > 0)
			{
				y = argv[x];
				argv[x] = argv[x + 1];
				argv[x + 1] = y;
			}
			x++;
		}
		z++;
	}
	ft_printarray(argc,argv);
	return (0);
}
